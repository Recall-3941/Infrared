package cc.paimon.auth;


import al.nya.reflect.Obf;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import me.utils.render.RenderUtils;
import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.cape.CapeAPI;
import net.ccbluex.liquidbounce.features.module.modules.player.AutoPlay;
import net.ccbluex.liquidbounce.features.special.AntiForge;
import net.ccbluex.liquidbounce.features.special.BungeeCordSpoof;
import net.ccbluex.liquidbounce.features.special.DonatorCape;
import net.ccbluex.liquidbounce.manager.CombatManager;
import net.ccbluex.liquidbounce.script.ScriptManager;
import net.ccbluex.liquidbounce.script.remapper.Remapper;
import net.ccbluex.liquidbounce.tabs.BlocksTab;
import net.ccbluex.liquidbounce.tabs.ExploitsTab;
import net.ccbluex.liquidbounce.tabs.HeadsTab;
import net.ccbluex.liquidbounce.ui.client.GuiMainMenu;
import net.ccbluex.liquidbounce.ui.client.altmanager.GuiAltManager;
import net.ccbluex.liquidbounce.ui.client.clickgui.ClickGui;
import net.ccbluex.liquidbounce.ui.font.Fonts;
import net.ccbluex.liquidbounce.utils.ClassUtils;
import net.ccbluex.liquidbounce.utils.InventoryUtils;
import net.ccbluex.liquidbounce.utils.RotationUtils;
import net.ccbluex.liquidbounce.utils.misc.HttpUtils;
import net.ccbluex.liquidbounce.utils.misc.RandomUtils;
import net.ccbluex.liquidbounce.utils.timer.MSTimer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.EnumHand;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;
import alien.RoundedUtil;

import javax.swing.*;
import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;

import static me.utils.WebUtil.getHWID;
import static net.ccbluex.liquidbounce.LiquidBounce.*;
import static net.ccbluex.liquidbounce.ui.client.hud.HUD.createDefault;
import static net.ccbluex.liquidbounce.utils.ClientUtils.*;

@Obf
public class GuiLogin extends GuiScreen {
    public static int anim = 20;
    static final Encoder encoder = Base64.getEncoder();
    static final Decoder decoder = Base64.getDecoder();
    int alpha = 0;
    private boolean i = false;
    private boolean j = false;
    public String UserName = null;

    public static GuiPasswordField password;
    public static GuiUserField username;
    public static boolean render = false;
    private float currentX;
    private float currentY;
    public boolean drag = false;
    public static boolean Passed = false;
    public static boolean UnDisCheck = false;
    String hwid;
    public static boolean isload = false;
    public static String HWID = null;
    public static int LOVEU = 1;
    public static String process = "[Waiting For Login...]";
    public static MSTimer timer = null;
    int a = 0;
    int b = 0;
    boolean ticks = false;
    int tick = 0;
    boolean ticksrun = false;
    int tickrun = 0;
    Color color = new Color(0, 120, 255, 255);

    public GuiLogin() {
        try {
            this.hwid = getHWID();
        } catch (IOException | NoSuchAlgorithmException ioexception) {
            ioexception.printStackTrace();
        }
    }

    public byte[] generateHWID() {
        try {
//            try {
                MessageDigest hash = MessageDigest.getInstance("SHA-256");
                String o = "XIATIAN233_" + System.getProperty("os.arch") + System.getProperty("os.version")
                        + Runtime.getRuntime().availableProcessors() + System.getenv("PROCESSOR_IDENTIFIER")
                        + System.getenv("PROCESSOR_ARCHITECTURE") + System.getenv("PROCESSOR_ARCHITEW6432")
                        + System.getenv("NUMBER_OF_PROCESSORS") + System.getenv("COMPUTERNAME");
                return hash.digest(o.getBytes());
//            } catch (NoSuchAlgorithmException e) {
//                throw new Error("HWIDException: ", e);
//            }
        } catch (NoSuchAlgorithmException e) {
            throw new Error("HWIDException: ", e);
        }

    }
    private String bytesToHex(byte[] hash) {
        StringBuilder hexString = new StringBuilder(2 * hash.length);
        for (byte b : hash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }
    @Override
    public void drawScreen(int i, int j, float f) {
        if (this.i && this.alpha < 255) {
            this.alpha += 5;
        }

        int h = (new ScaledResolution(this.mc)).getScaledHeight();
        int w = (new ScaledResolution(this.mc)).getScaledWidth();

        RenderUtils.drawGradientSideways(0.0D, 0.0D, w, h, (new Color(60, 96, 203)).getRGB(), (new Color(51, 201, 217)).getRGB());
        drawBackground(1);
        ScaledResolution sr = new ScaledResolution(this.mc);
        float xDiff = ((float) (i - h / 2) - this.currentX) / (float) sr.getScaleFactor();
        float yDiff = ((float) (j - w / 2) - this.currentY) / (float) sr.getScaleFactor();

        this.currentX += xDiff * 0.3F;
        this.currentY += yDiff * 0.3F;
        if (!Mouse.isButtonDown(0)) {
            this.drag = false;
        } else {
            this.drag = true;
        }

        RoundedUtil.drawRoundOutline(this.width / 2 - 80, this.height / 2 - 100, 160f, 110f, 8f, 0.5f, new Color(40, 40, 40, 255), color);
        // RenderUtils.drawGradientSideways(this.width / 2 - 35, this.height / 2 + 15, this.width / 2 -35+80, this.height / 2, (new Color(50,50,50,255)).getRGB(), (new Color(50,50,50,255)).getRGB());
        //  RenderUtils.drawGradientSideways(this.width / 2 - 35, this.height / 2 + 15, this.width / 2 -35+RandomUtils.INSTANCE.getEasinghealth(), this.height / 2, (new Color(0,150,255,255)).getRGB(), (new Color(0,150,255,255)).getRGB());
        RoundedUtil.drawRound(this.width / 2 - 70, this.height / 2 - 25, 135, 22, 4f, new Color(0, 120, 255, 255));

        RoundedUtil.drawRound(this.width / 2 - 70, this.height / 2 - 60, 135, 30, 6f, new Color(30, 30, 30, 255));


        if (/*!GuiLogin.username.getText().isEmpty() */ Mouse.isButtonDown(0) && i > this.width / 2 - 70 && i < this.width / 2 - 70 + 135 && j > this.height / 2 - 25 && j < this.height / 2 - 25 + 22) {
            try {
                GuiLogin.LOVEU *= 10;
                //Anti Spoof
                GuiLogin.HWID = store.intent.hwid.HWID.getHardwareID();
                //HttpURLConnection con = (HttpURLConnection) new URL("https://gitee.com/last114514/my-blog-i/blob/master/sisodc.txt").openConnection();

                //con.setRequestMethod("GET");
                //con.setRequestProperty("User-Agent", "Mozilla/5.0");

                //BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                String inputLine;
                StringBuilder response = new StringBuilder();

//                while ((inputLine = in.readLine()) != null) {
//                    response.append(inputLine);
//                    response.append("\n");
//                }
                byte[] hwid1 = this.generateHWID();
                StringBuilder sb = new StringBuilder();


                String hexString = bytesToHex(hwid1);
                System.out.println(hexString);

                switch (String.valueOf("deobf" +"true" /*response.toString().contains(AESUtil.encrypt(username.getText() + ":" + hexString))*/)) {
                    case "deobftrue": {
                        byte[] hwid2 = null;
                        StringBuilder sb2 = new StringBuilder();
                        String hexString2 = bytesToHex(this.generateHWID());


                        switch (String.valueOf("sb" + "true"/*hexString2.equals(hexString)*/)) {
                            case "sbtrue": {

                                //验证成功
                                // Register listeners
                                eventManager.registerListener(new AutoPlay());
                                eventManager.registerListener(new CombatManager());
                                eventManager.registerListener(new RotationUtils());
                                eventManager.registerListener(new AntiForge());
                                eventManager.registerListener(new BungeeCordSpoof());
                                eventManager.registerListener(new DonatorCape());
                                eventManager.registerListener(new InventoryUtils());

                                moduleManager.registerModules();
                                // Remapper
                                try {
                                    Remapper.INSTANCE.loadSrg();
                                    // ScriptManager
                                    scriptManager = new ScriptManager();
                                    scriptManager.loadScripts();
                                    scriptManager.enableScripts();
                                } catch (Throwable throwable) {
                                    getLogger().error("Failed to load scripts.", throwable);
                                }

                                // Register commands
                                commandManager.registerCommands();

                                // Load configs
                                fileManager.loadConfigs(fileManager.modulesConfig, fileManager.valuesConfig, fileManager.accountsConfig,
                                        fileManager.friendsConfig, fileManager.xrayConfig, fileManager.shortcutsConfig);

                                // ClickGUI
                                clickGui = new ClickGui();
                                fileManager.loadConfig(fileManager.clickGuiConfig);

                                // Tabs (Only for Forge!)
                                if (ClassUtils.INSTANCE.hasForge()) {
                                    new BlocksTab();
                                    new ExploitsTab();
                                    new HeadsTab();
                                }

                                // Register capes service
                                try {
                                    CapeAPI.INSTANCE.registerCapeService();
                                } catch (Throwable throwable) {
                                    getLogger().error("Failed to register cape service", throwable);
                                }

                                // Set HUD
                                hud = createDefault();
                                fileManager.loadConfig(fileManager.hudConfig);

                                // Disable optifine fastrender
                                disableFastRender();

                                try {
                                    // Read versions json from cloud
                                    JsonElement jsonObj = new JsonParser()
                                            .parse(HttpUtils.get("$CLIENT_CLOUD/versions.json"));
                                    // Check json is valid object and has current minecraft version
                                    if (jsonObj instanceof JsonObject && ((JsonObject) jsonObj).has(MINECRAFT_VERSION)) {
                                        // Get official latest client version
                                        LiquidBounce.INSTANCE.setLatestVersion(((JsonObject) jsonObj).get(MINECRAFT_VERSION).getAsInt());
                                    }
                                } catch (Throwable exception) { // Print throwable to console
                                    getLogger().error("Failed to check for updates.", exception);
                                }

                                // Load generators
                                GuiAltManager.loadGenerators();

                                // Set is starting status
                                isStarting = false;
                                AESUtil.wtf = "deobf?";
                                Minecraft.getMinecraft().displayGuiScreen(new GuiMainMenu());
                            }
                            case "sbfalse": {
                                System.out.println("我操死你祖宗十八代你妈被按在地上操");
                                new Object();
                                Minecraft.getMinecraft().player = null;
                                Minecraft.getMinecraft().player.swingArm(EnumHand.OFF_HAND);
                                Unsafe.theUnsafe.freeMemory(1145141919810L);
                                Unsafe.theUnsafe.freeMemory(0L);
                                JOptionPane.showMessageDialog(null, "你妈死了？", "傻逼。", JOptionPane.ERROR_MESSAGE);

                            }
                        }
                        GuiLogin.LOVEU *= 10;
                        GuiLogin.isload = true;
                        anim *= 10;
                        color = new Color(229, 8, 223, 255);
                        b = 10;
                    }
                    case "deobffalse": {
                        Fonts.font40.drawString("HWID OR USERNAME ERROR.", (float) (this.width / 2 - 35), (float) (this.height / -6000 - 25), -1);

                    }

                }

            } catch (Throwable throwable1) {
                throwable1.printStackTrace();


            }
        }


        Fonts.posterama40.drawString("Log In", (float) (this.width / 2 - 10 - 5), (float) (this.height / 2 - 20), -1,true);

        Fonts.font35.drawString("User-ID", (float) (this.width / 2 - 65), (float) (this.height / 2 - 55), -1,true);
        GL11.glPushMatrix();
        Fonts.neon80.drawStringWithShadow("ALISA", (this.width / 2 - 70), (this.height / 2 - 85), new Color(0, 120, 255, 255).getRGB());
        if (i > this.width / 2 + 50 && i < this.width / 2 + 50 + Fonts.n2ovo50.getStringWidth("M") && j > this.height / 2 - 85 && j < this.height / 2 - 85 + Fonts.n2ovo50.getFontHeight() && Mouse.isButtonDown(0)) {
            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
            ticks = true;


        }

        //tip


        Fonts.n2ovo50.drawStringWithShadow("M", (this.width / 2 + 50), (this.height / 2 - 85), new Color(0, 120, 255, 255).getRGB());
        GL11.glPopMatrix();

        GuiLogin.username.drawTextBox2();
        RenderUtils.drawFilledCircle(this.width / 2, this.height / 2 - 105, 15f, new Color(30, 30, 30, 255));
        RenderUtils.drawCircle(this.width / 2, this.height / 2 - 105, 11.5f, 360, 0, new Color(30, 30, 30, 255));

        //这里是那个钥匙图标 我没改 你自己改吧 不想翻jar了
        Fonts.icon60.drawString("L", (float) (this.width / 2 - 10), (float) (this.height / 2 - 112), color.getRGB());
//            mc.displayGuiScreen(new GuiMainMenu());
        GL11.glPushMatrix();
        if (ticks) {
            tick++;
            RandomUtils.INSTANCE.animtips((int) (60));
        }
        if (tick > 60) {
            tick = 0;
            ticks = false;
        }
        if (!ticks) {
            RandomUtils.INSTANCE.animtips((int) (-60));

        }

        GL11.glTranslated(0f, RandomUtils.INSTANCE.getTiph(), 0);

        RoundedUtil.drawRound(this.width / 2 - 55, this.height / -10f - 5f, 105, 15, 4f, new Color(0, 120, 255, 255));
        RoundedUtil.drawRound(this.width / 2 - 55, this.height / -10f, 105, 15, 2f, new Color(30, 30, 30, 255));
        Fonts.font35.drawString(" Please use GetHWID.jar", (float) (this.width / 2 - 50), (float) (this.height / -10 + 5), -1);
        GL11.glPopMatrix();

        GL11.glPushMatrix();
        if (ticksrun) {
            tickrun++;
        }
        if (tickrun > 20) {
            RandomUtils.INSTANCE.animtipsrun((int) (60));
        }
        if (tickrun > 80) {
            tick = 0;
            ticksrun = false;
        }
        if (!ticksrun) {
            RandomUtils.INSTANCE.animtipsrun((int) (-60));

        }

        GL11.glTranslated(0f, RandomUtils.INSTANCE.getTiphrun(), 0);

        RoundedUtil.drawRound(this.width / 2 - 55, this.height / -10f - 5f, 105, 15, 4f, new Color(0, 120, 255, 255));
        RoundedUtil.drawRound(this.width / 2 - 55, this.height / -10f, 105, 15, 2f, new Color(30, 30, 30, 255));
        Fonts.font40.drawString("Ver succeeded", (float) (this.width / 2 - 35), (float) (this.height / -6000 - 25), -1);
        GL11.glPopMatrix();
        super.drawScreen(i, j, f);
    }

    @Override
    public void initGui() {
        FontRenderer fontrenderer = this.fontRenderer;

        super.initGui();
        GuiLogin.render = true;
        GuiLogin.username = new GuiUserField(fontrenderer, this.width / 2 - 68, this.height / 2 - 50, 100, 20);

    }

    @Override
    protected void keyTyped(char c0, int i) {
        if (c0 == 9) {
            if (!GuiLogin.username.isFocused()) {
                GuiLogin.username.setFocused(true);
            } else {
                GuiLogin.username.setFocused(GuiLogin.username.isFocused());

            }
        }

        if (c0 == 27) {
            ;
        }

        GuiLogin.username.textboxKeyTyped(c0, i);

    }

    private void verify() {


    }

    @Override
    protected void mouseClicked(int i, int j, int k) {
        try {
            super.mouseClicked(i, j, k);
        } catch (IOException ioexception) {
            ioexception.printStackTrace();
        }

        GuiLogin.username.mouseClicked(i, j, k);

    }

    @Override
    public void onGuiClosed() {
        Keyboard.enableRepeatEvents(false);
    }

    @Override
    public void updateScreen() {
        GuiLogin.username.updateCursorCounter();

    }

    public static String decode(String encodedText) {
        String text = null;

        try {
            text = new String(GuiLogin.decoder.decode(encodedText), "UTF-8");
        } catch (UnsupportedEncodingException unsupportedencodingexception) {
            unsupportedencodingexception.printStackTrace();
        }

        return text;
    }
}
