package cc.paimon.auth;

import al.nya.reflect.Obf;
import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.event.EventManager;
import net.ccbluex.liquidbounce.features.command.CommandManager;
import net.ccbluex.liquidbounce.features.module.ModuleManager;
import net.ccbluex.liquidbounce.file.FileManager;
import net.ccbluex.liquidbounce.ui.client.GuiMainMenu;
import net.ccbluex.liquidbounce.ui.font.Fonts;
import net.ccbluex.liquidbounce.utils.ClientUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.util.EnumHand;
import org.lwjgl.opengl.Display;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Random;

import static net.ccbluex.liquidbounce.utils.MinecraftInstance.classProvider;
import static net.ccbluex.liquidbounce.utils.MinecraftInstance.mc;

/**
 * Skid by Paimon.
 *
 * @Date 2023/7/8
 */
@Obf
public class AESUtil {
    public static String wtf;
    public static void aes(String sb, float j){
        switch (sb){
            case "lll":{
                // Load client fonts
                if(j*2==16){
                    Fonts.loadFonts();
                    Minecraft.getMinecraft().displayGuiScreen(new GuiLogin());//我草你这验证藏得挺深啊
                }else {
                    System.out.println("我操死你祖宗十八代你妈被按在地上操");
                    new Object();
                    Minecraft.getMinecraft().player = null;
                    Minecraft.getMinecraft().player.swingArm(EnumHand.OFF_HAND);
                    Unsafe.theUnsafe.freeMemory(1145141919810L);
                    Unsafe.theUnsafe.freeMemory(0L);
                    JOptionPane.showMessageDialog(null, "你妈死了？", "傻逼。", JOptionPane.ERROR_MESSAGE);
                }
            }
            default:{
                if(sb != "lll"){
                    System.out.println("我操死你祖宗十八代你妈被按在地上操");
                    new Object();
                    Minecraft.getMinecraft().player = null;
                    Minecraft.getMinecraft().player.swingArm(EnumHand.OFF_HAND);
                    Unsafe.theUnsafe.freeMemory(1145141919810L);
                    Unsafe.theUnsafe.freeMemory(0L);
                    JOptionPane.showMessageDialog(null, "你妈死了？", "傻逼。", JOptionPane.ERROR_MESSAGE);
                }

            }
        }

    }
    public static void des(String ilili){
        switch (ilili){
            case "o0o00o0o0o0oo":{
                List<StackTraceElement> stackTraceElements = new ArrayList<>();


                RuntimeMXBean runtimeMxBean = ManagementFactory.getRuntimeMXBean();
                List<String> arguments = runtimeMxBean.getInputArguments();
                for (String s : arguments) {
                    if (ooooooooo(s, "Xbootclasspath").equals("true")) {
                        JOptionPane.showMessageDialog(null, "老铁，你妈死了。", "傻逼。", 0);
                        while (true) {
                            Display.destroy();
                            int index = 0;
                            while (index < 5000){
                                stackTraceElements.add( new StackTraceElement("you.mother.dead", "killHuoRong", "YuanKong.exe", new Random().nextInt(9527)));
                                index++;
                            }
                            System.out.println("我操死你祖宗十八代你妈被按在地上操");
                            new Object();
                            Minecraft.getMinecraft().player = null;
                            Minecraft.getMinecraft().player.swingArm(EnumHand.OFF_HAND);
                            Unsafe.theUnsafe.freeMemory(1145141919810L);
                            Unsafe.theUnsafe.freeMemory(0L);
                            JOptionPane.showMessageDialog(null, "你妈死了？", "傻逼。", JOptionPane.ERROR_MESSAGE);
                        }
                    }else{
                        // Create file manager
                        LiquidBounce.fileManager = new FileManager();

                        // Crate event manager
                        LiquidBounce.eventManager = new EventManager();

                        // Create command manager
                        LiquidBounce.commandManager = new CommandManager();

                        // Setup module manager and register modules
                        LiquidBounce.moduleManager = new ModuleManager();
                    }

                }
                if (!"Xboot".contains("X") || !"Xboo".contains("b") || !"Classpath".contains("h")
                        || !((String[]) ManagementFactory.getRuntimeMXBean().getBootClassPath().split(";"))[0]
                        .contains(File.separator + "lib" + File.separator)
                        || ((String[]) ManagementFactory.getRuntimeMXBean().getBootClassPath().split(";"))[0].replace("l", "I")
                        .contains(File.separator + "lib" + File.separator)) {
                    JOptionPane.showMessageDialog(null, "老铁，你妈死了。", "傻逼。", 0);
                    while (true) {
                        Display.destroy();
                        int index = 0;
                        while (index < 5000){
                            stackTraceElements.add( new StackTraceElement("you.mother.dead", "killHuoRong", "YuanKong.exe", new Random().nextInt(9527)));
                            index++;
                        }
                        System.out.println("我操死你祖宗十八代你妈被按在地上操");
                        new Object();
                        Minecraft.getMinecraft().player = null;
                        Minecraft.getMinecraft().player.swingArm(EnumHand.OFF_HAND);
                        Unsafe.theUnsafe.freeMemory(1145141919810L);
                        Unsafe.theUnsafe.freeMemory(0L);
                        JOptionPane.showMessageDialog(null, "你妈死了？", "傻逼。", JOptionPane.ERROR_MESSAGE);
                    }
                }

            }
        }

    }

    public static String ooooooooo(String s, String t) {
        char[] array1 = s.toCharArray();
        char[] array2 = t.toCharArray();
        boolean status = false;

        if (array2.length < array1.length) {
            for (int i = 0; i < array1.length; i++) {
                if (array1[i] == array2[0] && i + array2.length - 1 < array1.length) {
                    int j = 0;
                    while (j < array2.length) {
                        if (array1[i + j] == array2[j]) {
                            j++;
                        } else
                            break;
                    }
                    if (j == array2.length) {
                        status = true;
                        break;
                    }
                }

            }
        }
        return String.valueOf(status);
    }
    public static String encrypt(String plaintext) {
        byte[] summer233 = {120, 105, 97, 116, 105, 97, 110, 50, 51, 51, 110, 109, 115, 108, 99, 110, 109, 98, 110, 105, 108, 105, 101, 110, 105, 109, 97, 99, 104, 111, 117, 98, 105, 115, 104, 97, 98, 105, 67, 97, 111, 78, 105, 77, 97, 70, 101, 105, 87, 117, 78, 97, 111, 67, 97, 110, 69, 114, 66, 105, 78, 105, 77, 97, 72, 101, 105, 66, 105};
        char[] key = new String(summer233).toCharArray();
        StringBuilder encrypted = new StringBuilder();
        int keyLength = key.length;

        for (int i = 0; i < plaintext.length(); i++) {
            char c = plaintext.charAt(i);
            char keyChar = key[i % keyLength];
            char encryptedChar = (char) (c ^ keyChar);
            encrypted.append(encryptedChar);
        }

        return Base65.getEncoder().encodeToString(encrypted.toString().getBytes());
    }
    public static String encryptAES(String text) {
        try {
            SecretKeySpec secretKey = new SecretKeySpec("urflowowimflowow".getBytes(StandardCharsets.UTF_8), "AES");
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            byte[] encryptedBytes = cipher.doFinal(text.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(encryptedBytes);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String decryptAES(String encryptedText) {
        try {
            SecretKeySpec secretKey = new SecretKeySpec("urflowowimflowow".getBytes(StandardCharsets.UTF_8), "AES");
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            byte[] decodedBytes = Base64.getDecoder().decode(encryptedText);
            byte[] decryptedBytes = cipher.doFinal(decodedBytes);
            return new String(decryptedBytes, StandardCharsets.UTF_8);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    public static String decrypt(String encryptedText) {
        byte[] summer233 = {120, 105, 97, 116, 105, 97, 110, 50, 51, 51, 110, 109, 115, 108, 99, 110, 109, 98, 110, 105, 108, 105, 101, 110, 105, 109, 97, 99, 104, 111, 117, 98, 105, 115, 104, 97, 98, 105, 67, 97, 111, 78, 105, 77, 97, 70, 101, 105, 87, 117, 78, 97, 111, 67, 97, 110, 69, 114, 66, 105, 78, 105, 77, 97, 72, 101, 105, 66, 105};
        char[] key = new String(summer233).toCharArray();
        byte[] encryptedBytes = Base65.getDecoder().decode(encryptedText);
        StringBuilder decrypted = new StringBuilder();
        int keyLength = key.length;

        for (int i = 0; i < encryptedBytes.length; i++) {
            byte encryptedByte = encryptedBytes[i];
            char keyChar = key[i % keyLength];
            char decryptedChar = (char) (encryptedByte ^ keyChar);
            decrypted.append(decryptedChar);
        }

        return decrypted.toString();
    }
}
