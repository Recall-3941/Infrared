package alien.tenacity.utils.render;

@FunctionalInterface
public interface RenderCallback {
    void render();
}
