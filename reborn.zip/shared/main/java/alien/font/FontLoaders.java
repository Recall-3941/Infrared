package alien.font;

import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;

import java.awt.*;

public abstract class FontLoaders {
    public static FontDrawer F18;
    public static FontDrawer F16;
    public static FontDrawer P16;
    public static FontDrawer PR16;
    public static FontDrawer PR20;

    public static FontDrawer PR40;


    public static void initFonts() {
        F18 = getFont("msyh", 18, true);
        F16 = getFont("msyh", 16, true);
        P16 = getFont("ppr",16,true);
        PR16 = getFont("prod",16,true);
        PR20 = getFont("prod",20,true);
        PR40 = getFont("prod",40,true);
    }


    public static FontDrawer getFont(String name, int size, boolean antiAliasing) {
        Font font;
        try {
            font = Font.createFont(0, Minecraft.getMinecraft().getResourceManager().getResource(new ResourceLocation("liquidbounce/font/" + name + ".ttf")).getInputStream()).deriveFont(Font.PLAIN, (float) size);
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Error loading font");
            font = new Font("default", Font.PLAIN, size);
        }
        return new FontDrawer(font, antiAliasing);
    }
}
