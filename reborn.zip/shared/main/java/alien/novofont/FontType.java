package alien.novofont;

@SuppressWarnings("SpellCheckingInspection")
public enum FontType {



    Novoicon("iconnovo.ttf");




    private final String fileName;

    FontType(String fileName) {
        this.fileName = fileName;
    }

    public String fileName() { return fileName; }
}
