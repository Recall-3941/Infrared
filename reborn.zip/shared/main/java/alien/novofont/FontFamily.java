/*
 * FDPClient Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge by LiquidBounce.
 * https://github.com/UnlegitMC/FDPClient/
 */
package alien.novofont;

public interface FontFamily {

    FontRenderer ofSize(int size);

    FontType font();
}
