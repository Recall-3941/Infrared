/*
 * FDPClient Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge by LiquidBounce.
 * https://github.com/UnlegitMC/FDPClient/
 */
package alien.novofont ;


@SuppressWarnings("SpellCheckingInspection")
public interface Fonts {
    public final static String
            BUG = "a",
            LIST = "b",
            BOMB = "c",
            EYE = "d",
            PERSON = "e",
            WHEELCHAIR = "f",
            SCRIPT = "g",
            SKIP_LEFT = "h",
            PAUSE = "i",
            PLAY = "j",
            SKIP_RIGHT = "k",
            SHUFFLE = "l",
            INFO = "m",
            SETTINGS = "n",
            CHECKMARK = "o",
            XMARK = "p",
            TRASH = "q",
            WARNING = "r",
            FOLDER = "s",
            LOAD = "t",
            SAVE = "u";
    FontManager FONT_MANAGER = (FontManager) Client.getFontManager();

    interface NovolineIcon{
        FontFamily NovolineIcon = FONT_MANAGER.fontFamily(FontType.Novoicon);
        final class NovolineIcon75 {public static  final  FontRenderer NovolineIcon75 = NovolineIcon.ofSize(75); private NovolineIcon75() {}}
        final class NovolineIcon45 {public static  final  FontRenderer NovolineIcon45= NovolineIcon.ofSize(35); private NovolineIcon45() {}}
    }



}
