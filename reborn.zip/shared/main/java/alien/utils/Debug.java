package alien.utils;

import net.ccbluex.liquidbounce.utils.MinecraftInstance;


public class Debug extends MinecraftInstance {
    public static Boolean thePlayerisBlocking = false;

}