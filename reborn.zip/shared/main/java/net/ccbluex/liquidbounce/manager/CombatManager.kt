package net.ccbluex.liquidbounce.manager

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntityLivingBase
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.utils.EntityUtils
import net.ccbluex.liquidbounce.utils.MinecraftInstance
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import alien.utils.info.Recorder

class CombatManager : Listenable, MinecraftInstance() {
    private val lastAttackTimer = MSTimer()

    var inCombat = false
    var target: IEntityLivingBase? = null
        private set
    private val attackedEntityList = mutableListOf<IEntityLivingBase>()


    @EventTarget
    fun onAttack(event: AttackEvent) {
        val target = event.targetEntity

        if (classProvider.isEntityLivingBase(target) && EntityUtils.isSelected(target, true)) {
            this.target = target as IEntityLivingBase?
            if (!attackedEntityList.contains(target!!)) {
                attackedEntityList.add(target)
            }
        }
        lastAttackTimer.reset()
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        attackedEntityList.filter { it.isDead }.forEach {
            Recorder.killCounts++
            LiquidBounce.eventManager.callEvent(EntityKilledEvent(it))
            attackedEntityList.remove(it)
        }

        inCombat = false

        if (!lastAttackTimer.hasTimePassed(1000)) {
            inCombat = true
            return
        }

        if (target != null) {
            if (mc.thePlayer!!.getDistanceToEntity(target!!) > 7 || !inCombat || target!!.isDead) {
                target = null
            } else {
                inCombat = true
            }
        }
    }

    override fun handleEvents() = true
}