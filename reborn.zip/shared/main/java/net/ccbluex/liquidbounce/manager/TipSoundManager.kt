
package net.ccbluex.liquidbounce.manager

import net.ccbluex.liquidbounce.LiquidBounce
import alien.blur.FileUtils
import java.io.File

class TipSoundManager {
    var enableSound : TipSoundPlayer
    var disableSound : TipSoundPlayer
    var pride_enableSound : TipSoundPlayer
    var pride_disableSound : TipSoundPlayer
    var fdp_enableSound : TipSoundPlayer
    var fdp_disableSound : TipSoundPlayer

    init {
        val enableSoundFile=File(LiquidBounce.fileManager.soundsDir,"enable.wav")
        val disableSoundFile=File(LiquidBounce.fileManager.soundsDir,"disable.wav")
        val pride_enableSoundFile=File(LiquidBounce.fileManager.soundsDir,"pride_enable.wav")
        val pride_disableSoundFile=File(LiquidBounce.fileManager.soundsDir,"pride_disable.wav")
        val fdp_enableSoundFile=File(LiquidBounce.fileManager.soundsDir,"fdp_enable.wav")
        val fdp_disableSoundFile=File(LiquidBounce.fileManager.soundsDir,"fdp_disable.wav")

        if(!enableSoundFile.exists())
            FileUtils.unpackFile(enableSoundFile,"assets/minecraft/liquidbounce/sounds/enable.wav")
        if(!disableSoundFile.exists())
            FileUtils.unpackFile(disableSoundFile,"assets/minecraft/liquidbounce/sounds/disable.wav")
        if(!pride_enableSoundFile.exists())
            FileUtils.unpackFile(enableSoundFile,"assets/minecraft/liquidbounce/sounds/pride_enable.wav")
        if(!pride_disableSoundFile.exists())
            FileUtils.unpackFile(disableSoundFile,"assets/minecraft/liquidbounce/sounds/pride_disable.wav")
        if(!fdp_enableSoundFile.exists())
            FileUtils.unpackFile(enableSoundFile,"assets/minecraft/liquidbounce/sounds/fdp_enable.wav")
        if(!fdp_disableSoundFile.exists())
            FileUtils.unpackFile(disableSoundFile,"assets/minecraft/liquidbounce/sounds/fdp_disable.wav")

        enableSound=TipSoundPlayer(enableSoundFile)
        disableSound=TipSoundPlayer(disableSoundFile)
        pride_enableSound=TipSoundPlayer(pride_enableSoundFile)
        pride_disableSound=TipSoundPlayer(pride_disableSoundFile)
        fdp_enableSound=TipSoundPlayer(fdp_enableSoundFile)
        fdp_disableSound=TipSoundPlayer(fdp_disableSoundFile)
    }
}