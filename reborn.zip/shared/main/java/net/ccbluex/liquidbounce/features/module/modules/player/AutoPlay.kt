package net.ccbluex.liquidbounce.features.module.modules.player

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.ui.client.hud.element.elements.Notification
import net.ccbluex.liquidbounce.ui.client.hud.element.elements.NotifyType
import net.ccbluex.liquidbounce.value.TextValue
import net.minecraft.network.play.server.SPacketChat
import alien.utils.info.Recorder.totalPlayed

@ModuleInfo(name = "AutoPlay",spacedName = "Auto Play", category = ModuleCategory.PLAYER, description = "idk")
class AutoPlay : Module() {
    var fadeState = FadeState.NO
    var win = 0
    var kill = 0
    private val textValue = TextValue("Text", "@[Alisa]GG")
    @EventTarget
    fun onPacket(event: PacketEvent) {
        val packet = event.packet.unwrap()

        if (packet is SPacketChat) {
            val text = packet.chatComponent.unformattedText

            if (text.contains("      喜欢      一般      不喜欢", true)) {
                mc.thePlayer!!.sendChatMessage(textValue.get())
                win++
                LiquidBounce.hud.addNotification(Notification("AutoPlay", "You are the winner!", NotifyType.INFO))
                fadeState = FadeState.FRIST
            }
            if (text.contains("游戏开始", true)) {
                LiquidBounce.hud.addNotification(Notification("AutoPlay", "Game Start!", NotifyType.INFO))
                totalPlayed++
            }
            if (text.contains("[起床战争] Game 结束！感谢您的参与！", true)) {
                mc.thePlayer!!.sendChatMessage(textValue.get())
                LiquidBounce.hud.addNotification(Notification("AutoPlay","Game Over", NotifyType.INFO))

            }
            if (text.contains("你现在是观察者状态. 按E打开菜单.", true)) {
                mc.thePlayer!!.sendChatMessage(textValue.get())
                LiquidBounce.hud.addNotification(Notification("AutoPlay","Game Over", NotifyType.INFO))
            }
        }
    }
    override val tag: String
        get() = "HuaYuTing"
}
enum class FadeState { FRIST,IN, STAY, OUT, END,NO }
