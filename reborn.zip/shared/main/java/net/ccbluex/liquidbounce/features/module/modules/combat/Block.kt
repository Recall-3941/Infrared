/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.api.enums.EnumFacingType
import net.ccbluex.liquidbounce.api.minecraft.network.play.client.ICPacketPlayerDigging
import net.ccbluex.liquidbounce.api.minecraft.util.WBlockPos
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.EntityUtils
import net.ccbluex.liquidbounce.utils.Rotation
import net.ccbluex.liquidbounce.utils.RotationUtils
import net.ccbluex.liquidbounce.utils.extensions.getDistanceToEntityBox
import net.ccbluex.liquidbounce.utils.misc.RandomUtils
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.network.play.client.CPacketPlayerTryUseItem
import net.minecraft.network.play.client.CPacketUseEntity
import net.minecraft.util.EnumHand
import kotlin.random.Random

@ModuleInfo(name = "Block", description = "Automatically faces selected entities around you.", category = ModuleCategory.COMBAT)
class Block : Module() {
    private var blockingStatus = false
    private val rangeValue = FloatValue("BlockRange", 4.4F, 1F, 8F)
    private val Blockmodevalue = ListValue("BlockMode", arrayOf("KeyBind","Packet","NoAfterAttack"),"KeyBind")
    private val aura = LiquidBounce.moduleManager.getModule(KillAura::class.java) as KillAura
    private var canblock = false
    fun onMotion(event: MotionEvent) {
        if (event.eventState == EventState.POST) {
            if (aura.currentTarget != null && mc.thePlayer!!.getDistanceToEntity(aura.currentTarget!!) <= rangeValue.get()) {
                if (RotationUtils.getRotationDifference(aura.currentTarget) < 90) {
                    when (Blockmodevalue.get().toLowerCase()) {
                        "keybind" -> {
                            if (canblock) {
                                mc.gameSettings.keyBindUseItem.pressed = true
                            } else {
                                mc.gameSettings.keyBindUseItem.pressed = false
                            }
                        }
                        "packet" -> {
                            if (canblock) {
                                block()
                            } else {
                                unblock()
                            }
                        }
                        "noafterattack"->{
                            block()
                        }
                    }
                }
            }else if(aura.currentTarget == null && Blockmodevalue.get().toLowerCase()=="noafterattack"){
                unblock()
            }
        }
    }
    fun onPacket(event: PacketEvent){
        val packet = event.packet
        if(packet is CPacketUseEntity){
            canblock = false
        }else{
            canblock = true
        }
    }
    private fun block() {
        mc.playerController.sendUseItem(mc.thePlayer!!, mc.theWorld!!, mc.thePlayer!!.heldItem!!)
        mc.gameSettings.keyBindUseItem.pressed = true
        mc.thePlayer!!.sendQueue.addToSendQueue(
                classProvider.createCPacketPlayerBlockPlacement(WBlockPos(-1, -1, -1),
                        255,
                        mc.thePlayer!!.heldItem,
                        0F,
                        0F,
                        0F
                )
        )
        blockingStatus = true
    }
    private fun unblock() {
        if (blockingStatus) {
            mc.gameSettings.keyBindUseItem.pressed = false
            mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerDigging(ICPacketPlayerDigging.WAction.RELEASE_USE_ITEM, WBlockPos.ORIGIN, classProvider.getEnumFacing(EnumFacingType.DOWN)))
            blockingStatus = false
        }
    }
}