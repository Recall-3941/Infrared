/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.render

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.render.button.AbstractButtonRenderer
import net.ccbluex.liquidbounce.features.module.modules.render.button.RiseButtonRenderer
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import net.ccbluex.liquidbounce.value.TextValue
import net.minecraft.client.gui.GuiButton

@ModuleInfo(name = "HUD", description = "Toggles visibility of the HUD.", category = ModuleCategory.RENDER, array = false)
class HUD : Module() {
    val hueInterpolation = BoolValue("Hue Interpolate", false)
    private val toggleSoundValue = ListValue("ToggleSound", arrayOf("None", "Default", "Custom","Pride","FDP"), "Custom")
    private val toggleMessageValue = BoolValue("DisplayToggleMessage", true)
    val notificationStyle = ListValue("notificationStyle", arrayOf("Jello","Tomk","Windows11"),"Jello")
    val buttonValue = ListValue("Button", arrayOf("Rise"), "Rise")
    val blackHotbarValue = BoolValue("BlackHotbar", true)
    val inventoryParticle = BoolValue("InventoryParticle", false)
    private val blurValue = BoolValue("Blur", false)
    val Radius = IntegerValue("BlurRadius", 10 , 1 , 50 )
    val fontChatValue = BoolValue("FontChat", false)
    val chatRect = BoolValue("ChatRect", false)
    val chatAnimValue = BoolValue("ChatAnimation", true)
    companion object {
        @JvmField
        val shadowValue = ListValue(
                "ShadowMode", arrayOf(
                "LiquidBounce",
                "Outline",
                "Default"
        ), "LiquidBounce"
        )
        @JvmField
        val r = IntegerValue("Red", 255, 0, 255)
        @JvmField
        val g = IntegerValue("Green", 255, 0, 255)
        @JvmField
        val b = IntegerValue("Blue", 255, 0, 255)
        @JvmField
        val r2 = IntegerValue("Red2", 255, 0, 255)
        @JvmField
        val g2 = IntegerValue("Green2", 255, 0, 255)
        @JvmField
        val b2 = IntegerValue("Blue2", 255, 0, 255)
        @JvmField
        val gradientSpeed = IntegerValue("DoubleColor-Speed", 200, 10, 1000)
        @JvmField
        val colorModeValue = ListValue("HealthBarColor", arrayOf("Gident"), "Gident")
        @JvmField
        val clientname = TextValue("clientname", "Alisa")
    }
    fun getButtonRenderer(button: GuiButton): AbstractButtonRenderer? {
        return when (buttonValue.get().toLowerCase()) {
            "rise" -> RiseButtonRenderer(button)
            else -> null // vanilla or unknown
        }
    }
    @EventTarget
    fun onTick(event: TickEvent) {
        LiquidBounce.moduleManager.shouldNotify = toggleMessageValue.get()
        LiquidBounce.moduleManager.toggleSoundMode = toggleSoundValue.values.indexOf(toggleSoundValue.get())
    }
    @EventTarget
    fun onShader(event: ShaderEvent?) {
        if (classProvider.isGuiHudDesigner(mc.currentScreen))
            return

        LiquidBounce.hud.renderShader(false)
    }
    @EventTarget
    fun onRender2D(event: Render2DEvent?) {
        if (classProvider.isGuiHudDesigner(mc.currentScreen))
            return

        LiquidBounce.hud.render(false)
    }
    @EventTarget
    fun onUpdate(event: UpdateEvent?) {
        LiquidBounce.hud.update()
    }

    @EventTarget
    fun onKey(event: KeyEvent) {
        LiquidBounce.hud.handleKey('a', event.key)
    }

    @EventTarget(ignoreCondition = true)
    fun onScreen(event: ScreenEvent) {
        if (mc.theWorld == null || mc.thePlayer == null) return
        if (state && blurValue.get() && !mc.entityRenderer.isShaderActive() && event.guiScreen != null &&
                !(classProvider.isGuiChat(event.guiScreen) || classProvider.isGuiHudDesigner(event.guiScreen))) mc.entityRenderer.loadShader(classProvider.createResourceLocation("liquidbounce" + "/blur.json")) else if (mc.entityRenderer.shaderGroup != null &&
                mc.entityRenderer.shaderGroup!!.shaderGroupName.contains("liquidbounce/blur.json")) mc.entityRenderer.stopUseShader()
    }


    init {
        state = true
    }
}