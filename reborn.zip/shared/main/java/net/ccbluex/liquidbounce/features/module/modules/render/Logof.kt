//package net.ccbluex.liquidbounce.features.module.modules.render
//
//import alien.font.FontLoaders
//import alien.tenacity.utils.render.BloomUtil
//import alien.tenacity.utils.render.GradientUtil
//import alien.utils.ColorUtil
//import net.ccbluex.liquidbounce.LiquidBounce
//import net.ccbluex.liquidbounce.event.EventTarget
//import net.ccbluex.liquidbounce.event.Render2DEvent
//import net.ccbluex.liquidbounce.event.ShaderEvent
//import net.ccbluex.liquidbounce.features.module.Module
//import net.ccbluex.liquidbounce.features.module.ModuleCategory
//import net.ccbluex.liquidbounce.features.module.ModuleInfo
//import net.ccbluex.liquidbounce.ui.font.Fonts
//import net.ccbluex.liquidbounce.utils.EntityUtils
//import net.ccbluex.liquidbounce.utils.ServerUtils
//import net.ccbluex.liquidbounce.utils.render.ColorUtils
//import net.ccbluex.liquidbounce.utils.render.RenderUtils
//import net.ccbluex.liquidbounce.value.*
//import net.minecraft.client.Minecraft
//import net.minecraft.client.gui.ScaledResolution
//import net.minecraft.client.renderer.GlStateManager
//import net.minecraft.util.ResourceLocation
//import org.lwjgl.input.Keyboard
//import org.lwjgl.opengl.GL11
//import java.awt.Color
//import java.text.SimpleDateFormat
//import java.util.*
//import kotlin.math.hypot
//import kotlin.math.roundToLong
//
//@ModuleInfo(name = "Logo", description = ":)", category = ModuleCategory.RENDER, keyBind = Keyboard.KEY_G)
//class Logof : Module() {
//    val logoValue = ListValue("Logo", arrayOf("New"), "New")
//    private val colorMode = ListValue("LogoColorMode", arrayOf("Rainbow", "Light Rainbow", "Gident"), "Gident")
//    private val clientName = TextValue("ClientName", "Alisa")
//    val sColors = BoolValue("Colors", true)
//    val hueInterpolation = BoolValue("hueInterpolation", false)
//
//
//
//
//    @EventTarget
//    fun onShader(event: ShaderEvent?) {
//        when(logoValue.get().toLowerCase()) {
//            "new" -> {
//                GradientUtil.applyGradientHorizontal(5f, 5f,
//                        FontLoaders.PR40.getStringWidth(clientName.get()).toFloat(), 20f, 1f, clientColors[0], clientColors[1]) {
//                    RenderUtils.setAlphaLimit(0F)
//                    BloomUtil.drawAndBloom {
//                        FontLoaders.PR40.drawStringWithShadow(clientName.get(), 5.0, 5.0, Color(0, 0, 0, 0).rgb
//                        )
//                    }
//                }
//                GlStateManager.resetColor()
//                FontLoaders.PR40.drawStringWithShadow(clientName.get(), 5.0 + 1.0f, 5.0 + 1.0f, Color(0, 0, 0, 150).rgb)
//            }
//        }
//    }
//
//
//
//
//
//
//    @EventTarget
//    fun onRender2D(event: Render2DEvent?) {
//
//        val sigmaY = 4
//        val sigmaX = 8
//        // PlayTime
//        val clientColors = clientColors
//        when (logoValue.get().toLowerCase()) {
//
//
//
//            "new" -> {
//                GradientUtil.applyGradientHorizontal(5f, 5f,
//                        FontLoaders.PR40.getStringWidth(clientName.get()).toFloat(), 20f, 1f, clientColors[0], clientColors[1]) {
//                    RenderUtils.setAlphaLimit(0F)
//                    BloomUtil.drawAndBloom {
//                        FontLoaders.PR40.drawStringWithShadow(clientName.get(), 5.0, 5.0, Color(0, 0, 0, 0).rgb
//                        )
//                    }
//                }
//                GlStateManager.resetColor()
//
//            }
//        }
//
//    }
//    private fun mixColors(color1: Color, color2: Color): Color {
//        return if (sColors.get()) {
//            ColorUtil.interpolateColorsBackAndForth(
//                    15,
//                    1,
//                    color1,
//                    color2,
//                    hueInterpolation.get()
//            )
//        } else {
//            ColorUtil.interpolateColorC(color1, color2, 0F)
//        }
//    }
//
//    fun getClientColor(): Color {
//        return Color(HUD.r.get(), HUD.g.get(), HUD.b.get())
//    }
//
//    fun getAlternateClientColor(): Color {
//        return Color(HUD.r2.get(), HUD.g2.get(), HUD.b2.get())
//    }
//    val clientColors: Array<Color> get() {
//        val firstColor: Color
//        val secondColor: Color
//        when (colorMode.get().toLowerCase()) {
//            "light rainbow" -> {
//                firstColor = ColorUtil.rainbow(15, 1, .6f, 1f, 1f)
//                secondColor = ColorUtil.rainbow(15, 40, .6f, 1f, 1f)
//            }
//
//            "rainbow" -> {
//                firstColor = ColorUtil.rainbow(15, 1, 1f, 1f, 1f)
//                secondColor = ColorUtil.rainbow(15, 40, 1f, 1f, 1f)
//            }
//            "gident" -> {
//                firstColor =
//                        mixColors(getClientColor(), getAlternateClientColor())
//                secondColor =
//                        mixColors(getAlternateClientColor(), getClientColor())
//            }
//            else -> {
//                firstColor = Color(-1)
//                secondColor = Color(-1)
//            }
//        }
//        return arrayOf(firstColor, secondColor)
//    }
//    fun getFadeProgress() = 0f
//    fun getColor(color: Color) = ColorUtils.reAlpha(color, color.alpha / 255F * (1F - getFadeProgress()))
//    fun getColor(color: Int) = getColor(Color(color))
//
//
//
//    override val tag: String?
//        get() = logoValue.get()
//}
