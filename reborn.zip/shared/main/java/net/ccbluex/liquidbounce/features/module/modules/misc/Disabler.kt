package net.ccbluex.liquidbounce.features.module.modules.misc

import alien.PacketUtils
import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.WorldEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.combat.KillAura
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.injection.backend.wrap
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.client.gui.GuiDownloadTerrain
import net.minecraft.network.INetHandler
import net.minecraft.network.Packet
import net.minecraft.network.login.server.SPacketEncryptionRequest
import net.minecraft.network.play.client.*
import net.minecraft.network.play.server.*
import net.minecraft.network.status.server.SPacketPong
import net.minecraft.network.status.server.SPacketServerInfo
import net.ccbluex.liquidbounce.utils.MovementUtils

import java.util.concurrent.ConcurrentLinkedDeque
import java.util.concurrent.CopyOnWriteArrayList

@ModuleInfo(name = "Disabler", description = "Fuck Hyt", category = ModuleCategory.EXPLOIT)
class Disabler : Module() {

    val post = BoolValue("PostReset", true)
    private val autoBlockFix = BoolValue("RotationPlace", true)
    private val badPacketA = BoolValue("RefreshInv", false)
    private val fastBreak = BoolValue("FastBreak", true)
    private val c0B = BoolValue("InvalidC0B", false)

    val modeValue = ListValue("Mode", arrayOf("GrimAC"), "GrimAC")

    private var lastSlot: Int = -1
    private var lastAction = ""
    private var canSprint = false

    @EventTarget
    fun onPacket(event: PacketEvent) {
        val packet = event.packet.unwrap()
        val our = classProvider.isItemFood(mc.thePlayer!!.heldItem?.item)
                || classProvider.isItemPotion(mc.thePlayer!!.heldItem?.item)
                || classProvider.isItemBucketMilk(mc.thePlayer!!.heldItem?.item)
                || classProvider.isItemBow(mc.thePlayer!!.heldItem?.item)

        val killAura = LiquidBounce.moduleManager.getModule(KillAura::class.java) as KillAura
        if (packet is CPacketPlayerTryUseItemOnBlock && ( killAura.target != null || our) && autoBlockFix.get()) {
            event.cancelEvent()
        }

        if (fastBreak.get()) {
            val pw = event.packet.unwrap()
            if (pw is CPacketPlayerDigging && pw.action == CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK) {
                val connection = mc.unwrap().connection ?: return
                connection.sendPacket(
                        CPacketPlayerDigging(
                                CPacketPlayerDigging.Action.ABORT_DESTROY_BLOCK,
                                pw.position.add(0, 500, 0),
                                pw.facing
                        )
                )
            }
        }

        if (c0B.get()) {
            if (!MovementUtils.isMoving
                    || (mc.thePlayer!!.movementInput.moveForward < 0.8f
                            || mc.thePlayer!!.isInLava
                            || mc.thePlayer!!.isInWater
                            || mc.thePlayer!!.isInWeb
                            || mc.thePlayer!!.isOnLadder)) {
                canSprint = false
            } else {
                canSprint = true
            }

            if (packet is CPacketEntityAction) {
                if (packet.action.name == lastAction) {
                    event.cancelEvent()
                } else {
                    if (!canSprint && packet.action == CPacketEntityAction.Action.START_SPRINTING) {
                        event.cancelEvent()
                    } else {
                        lastAction = packet.action.name
                    }
                }
            }
        }

        if(badPacketA.get() && packet is CPacketHeldItemChange){
            val slot: Int = packet.slotId
            if (slot == this.lastSlot && slot != -1) {
                event.cancelEvent()
            }

            this.lastSlot = packet.slotId
        }
    }

    @EventTarget
    fun onWorld(event: WorldEvent) {
        lastSlot = -1
    }

    companion object {

        // Static
        @JvmStatic
        var storedPackets: MutableList<Packet<INetHandler>> = CopyOnWriteArrayList()

        @JvmStatic
        var pingPackets: ConcurrentLinkedDeque<Int> = ConcurrentLinkedDeque()

        @JvmStatic
        private var lastResult = false
    }

    fun getGrimPost(): Boolean {
        val disabler = LiquidBounce.moduleManager.getModule(Disabler::class.java)
        val result = disabler.state && modeValue.get() == "GrimAC" && post.get()
                && mc.thePlayer != null
                && mc.thePlayer!!.entityAlive
                && mc.thePlayer!!.ticksExisted >= 10
                && mc.currentScreen !is GuiDownloadTerrain

        if (lastResult && !result) {
            lastResult = false
            mc2.addScheduledTask { processPackets() }
        }

        return result.also { lastResult = it }
    }

    fun processPackets() {
        if (storedPackets.isNotEmpty()) {
            for (packet in storedPackets) {
                val event = PacketEvent(packet.wrap())
                LiquidBounce.eventManager.callEvent(event)
                if (event.isCancelled) {
                    continue
                }

                packet.processPacket(mc2.connection as INetHandler)
            }

            storedPackets.clear()
        }
    }

    fun grimPostDelay(packet: Packet<*>): Boolean {
        if (mc.thePlayer == null) {
            return false
        }

        if (mc.currentScreen is GuiDownloadTerrain) {
            return false
        }

        if (packet is SPacketServerInfo) {
            return false
        }

        if (packet is SPacketEncryptionRequest) {
            return false
        }

        if (packet is SPacketPlayerListItem) {
            return false
        }

        if (packet is SPacketDisconnect) {
            return false
        }

        if (packet is SPacketChunkData) {
            return false
        }

        if (packet is SPacketPong) {
            return false
        }

        if (packet is SPacketWorldBorder) {
            return false
        }

        if (packet is SPacketJoinGame) {
            return false
        }

        if (packet is SPacketEntityHeadLook) {
            return false
        }

        if (packet is SPacketTeams) {
            return false
        }

        if (packet is SPacketChat) {
            return false
        }

        if (packet is SPacketSetSlot) {
            return false
        }

        if (packet is SPacketEntityMetadata) {
            return false
        }

        if (packet is SPacketEntityProperties) {
            return false
        }

        if (packet is SPacketUpdateTileEntity) {
            return false
        }

        if (packet is SPacketTimeUpdate) {
            return false
        }

        if (packet is SPacketPlayerListHeaderFooter) {
            return false
        }

        if (packet is SPacketEntityVelocity) {
            val sPacketEntityVelocity: SPacketEntityVelocity = packet
            return sPacketEntityVelocity.entityID == mc.thePlayer!!.entityId
        }

        return packet is SPacketExplosion
                || packet is SPacketConfirmTransaction
                || packet is SPacketPlayerPosLook
                || packet is SPacketEntityEquipment
                || packet is SPacketBlockChange
                || packet is SPacketMultiBlockChange
                || packet is SPacketKeepAlive
                || packet is SPacketUpdateHealth
                || packet is SPacketEntity
                || packet is SPacketSpawnMob
                || packet is SPacketCustomPayload
    }

    fun fixC0F(packet: CPacketConfirmTransaction) {
        val id: Int = packet.uid.toInt()
        if (id >= 0 || pingPackets.isEmpty()) {
            PacketUtils.sendPacketNoEvent(packet)
        } else {
            do {
                val current: Int = pingPackets.first
                PacketUtils.sendPacketNoEvent(CPacketConfirmTransaction(packet.windowId, current.toShort(), true))
                pingPackets.pollFirst()
                if (current == id) {
                    break
                }

            } while (!pingPackets.isEmpty())
        }
    }

    override val tag: String
        get() = "GrimAC"
}