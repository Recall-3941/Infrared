/*
 * ColorByte Hacked Client
 * A free half-open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/SkidderRyF/ColorByte/
 */

package net.ccbluex.liquidbounce.features.module.modules.combat


import net.minecraft.entity.EntityLivingBase
import net.minecraft.entity.player.EntityPlayer
import net.minecraft.network.play.client.CPacketConfirmTransaction
import net.minecraft.network.play.client.CPacketEntityAction
import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntity
import net.ccbluex.liquidbounce.api.minecraft.network.play.client.ICPacketEntityAction
import net.ccbluex.liquidbounce.api.minecraft.network.play.client.ICPacketUseEntity
import net.ccbluex.liquidbounce.api.minecraft.util.WBlockPos
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.EnumAutoDisableType
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.injection.backend.wrap
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.utils.RaycastUtils
import net.ccbluex.liquidbounce.utils.RotationUtils
import net.ccbluex.liquidbounce.utils.extensions.getDistanceToEntityBox
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import kotlin.math.cos
import kotlin.math.sin

@ModuleInfo(
        name = "Velocity",
        description = "Edit your velocity",
        category = ModuleCategory.COMBAT,
        autoDisable = EnumAutoDisableType.FLAG
)
class Velocity : Module() {

    /**
     * OPTIONS
     */
    private val horizontalValue = FloatValue("Horizontal", 0.79F, 0F, 1F)
    private val verticalValue = FloatValue("Vertical", 0F, 0F, 1F)
    private val airReducerValue = FloatValue("airReducer", 0.95F, 0F, 1F).displayable { modeValue.get().equals("Smart") }

    private val modeValue = ListValue(
            "Mode", arrayOf("Grim-Reduce","Grim-Pit","Reduce","GrimAC",
            "Simple", "AAC", "AACPush", "AACZero",
            "Reverse", "SmoothReverse", "Jump", "Glitch", "Smart", "HytPit", "Grim", "Click", "NoXZ" , "NoXZ2" , "Cancel"
    ), "Smart"
    )

    // Reverse
    private val reverseStrengthValue = FloatValue("ReverseStrength", 1F, 0.1F, 1F).displayable { modeValue.get().equals("Reverse") }
    private val reverse2StrengthValue = FloatValue("SmoothReverseStrength", 0.05F, 0.02F, 0.1F).displayable { modeValue.get().equals("SmoothReverse") }

    // AAC Push
    private val aacPushXZReducerValue = FloatValue("AACPushXZReducer", 2F, 1F, 3F).displayable { modeValue.get().equals("AACPush") }
    private val msValue = FloatValue("msValue", 80F, 1F, 500F).displayable { modeValue.get().equals("AACPush") }

    // Smart
    private val wtapreduce = BoolValue("WTapReduce", false).displayable { modeValue.get().equals("Smart") }
    private val stapreduce = BoolValue("STapReduce", true).displayable { modeValue.get().equals("Smart") }
    private val legitPush = BoolValue("LegitPush", false).displayable { modeValue.get().equals("Smart") }
    private val legitFaceValue = BoolValue("LegitFace", false).displayable { modeValue.get().equals("Smart") }
    private val legitStrafeValue = BoolValue("LegitStrafe", false).displayable { modeValue.get().equals("Smart") }
    private val pushValue = FloatValue("PushSpeed", 0F, 0F, 1F).displayable { modeValue.get().equals("Smart") }
    private val Auto = BoolValue("AutoReduce", true).displayable { modeValue.get().equals("Smart") }
    private val onlyinRange = BoolValue("OnlyInRange", true).displayable { modeValue.get().equals("Smart") }
    private val distance = FloatValue("inRange", 4f, 0f, 6f).displayable { modeValue.get().equals("Smart") }

    // Click
    private val clickCount = IntegerValue("ClickCount", 2, 1, 10).displayable { modeValue.get().equals("Click") }
    private val clickTime = IntegerValue("ClickMinHurtTime", 8, 1, 10).displayable { modeValue.get().equals("Click") }
    private val clickRange = FloatValue("ClickRange", 3.0F, 2.5F, 7F).displayable { modeValue.get().equals("Click") }
    private val clickOnPacket = BoolValue("ClickOnPacket", true).displayable { modeValue.get().equals("Click") }
    private val clickSwing = BoolValue("ClickSwing", false).displayable { modeValue.get().equals("Click") }
    private val clickFakeSwing = BoolValue("ClickFakeSwing", true).displayable { modeValue.get().equals("Click") }

    // NoXZ2
    private val changesource = BoolValue("NoXZ2-ChangeSource", false).displayable { modeValue.get().equals("NoXZ2") }
    private val noblock = BoolValue("NoXZ2-Noblock", false).displayable { modeValue.get().equals("NoXZ2") }

    var radiansYaw = 0.0
    var xx = 0.0
    var zz = 0.0

    /**
     * VALUES
     */
    // legit smart
    private var jumped = 0
    var doinrange = true
    private var velocityTimer = MSTimer()
    private var velocityInput = false
    private var velocityInput2 = false
    private var velocityInput3 = false

    //potions
    private var x = 0.0
    private var z = 0.0

    //push
    private var d1 = 0.0
    private var d2 = 0.0
    private var pushtick = 0

    //face
    private var pos: WBlockPos? = null

    // SmoothReverse
    private var reverseHurt = false

    // AACPush
    private var jump = false

    //attack reduce
    private var attack = false

    override val tag: String
        get() = modeValue.get()

    override fun onDisable() {
        mc.thePlayer?.speedInAir = 0.02F
        velocityInput = false
        velocityInput2 = false
        attack = false
    }

    override fun onEnable() {
        velocityInput = false
        velocityInput2 = false
        attack = false
    }

    @EventTarget
    fun onStrafe(event: StrafeEvent) {
        when (modeValue.get().toLowerCase()) {
            "smart" -> {
                if (pos == null || mc.thePlayer!!.hurtTime <= 0)
                    return

                val rot = RotationUtils.getRotations(pos!!.x.toDouble(), pos!!.y.toDouble(), pos!!.z.toDouble())
                if (legitFaceValue.get() && !mc.thePlayer!!.onGround) {
                    RotationUtils.setTargetRotation(rot)
                }
                val yaw = rot.yaw
                if (legitStrafeValue.get()) {
                    val speed = MovementUtils.speed
                    val yaw1 = Math.toRadians(yaw.toDouble())
                    mc.thePlayer!!.motionX = -sin(yaw1) * speed
                    mc.thePlayer!!.motionZ = cos(yaw1) * speed
                }
            }

            "grim" -> {
                radiansYaw = Math.toRadians(getMoveYaw().toDouble())
                xx = -Math.sin(radiansYaw) * 0.2873
                zz = Math.cos(radiansYaw) * 0.2873
                mc.netHandler.addToSendQueue(
                        classProvider.createCPacketPlayerPosition(
                                mc.thePlayer!!.posX + x,
                                mc.thePlayer!!.posY,
                                mc.thePlayer!!.posZ + z,
                                false
                        )
                )
                mc.netHandler.addToSendQueue(
                        classProvider.createCPacketPlayerPosition(
                                mc.thePlayer!!.posX + x,
                                mc.thePlayer!!.posY - 999.0,
                                mc.thePlayer!!.posZ + z,
                                true
                        )
                )
            }

            "hytmotion" -> {
                if (velocityInput) {
                    if (attack) {
                        if (!changesource.get()) {
                            mc.thePlayer!!.motionX *= 0.077760000
                            mc.thePlayer!!.motionZ *= 0.077760000
                        }
                        velocityInput = false
                        attack = false
                    } else {
                        if (mc.thePlayer!!.hurtTime > 0) {
                            mc.thePlayer!!.motionX += -1.0E-7
                            mc.thePlayer!!.motionY += -1.0E-7
                            mc.thePlayer!!.motionZ += -1.0E-7
                            mc.thePlayer!!.isAirBorne = true
                        }
                        velocityInput = false
                        attack = false
                    }
                }

                if (velocityInput2) {
                    if (mc.thePlayer!!.onGround && mc.thePlayer!!.hurtTime == 9) {
                        if (jumped > 2) {
                            jumped = 0
                        } else {
                            ++jumped
                            if (mc.thePlayer!!.ticksExisted % 5 != 0) mc.gameSettings.keyBindJump.pressed = true
                        }
                    } else if (mc.thePlayer!!.hurtTime == 8) {
                        mc.gameSettings.keyBindJump.pressed = mc.gameSettings.isKeyDown(mc.gameSettings.keyBindJump)
                        velocityInput = false
                    }
                }
            }

            "hytpit" -> {
                if (pos == null || mc.thePlayer!!.hurtTime <= 0)
                    return

                val rot = RotationUtils.getRotations(pos!!.x.toDouble(), pos!!.y.toDouble(), pos!!.z.toDouble())
                if (legitFaceValue.get()) {
                    RotationUtils.setTargetRotation(rot)
                }
                val yaw = rot.yaw
                if (legitStrafeValue.get()) {
                    val speed = MovementUtils.speed
                    val yaw1 = Math.toRadians(yaw.toDouble())
                    mc.thePlayer!!.motionX = -sin(yaw1) * speed
                    mc.thePlayer!!.motionZ = cos(yaw1) * speed
                }
            }
        }
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        val thePlayer = mc.thePlayer ?: return
        val aura = LiquidBounce.moduleManager[KillAura::class.java]

        if (wtapreduce.get() && mc.thePlayer!!.hurtTime < 9)
            mc.gameSettings.keyBindForward.pressed = mc.gameSettings.isKeyDown(mc.gameSettings.keyBindForward)

        if (thePlayer.isInWater || thePlayer.isInLava || thePlayer.isInWeb)
            return
        for (entity in mc.theWorld!!.loadedEntityList) {
            doinrange =
                    entity.unwrap() is EntityLivingBase && entity.entityId != mc.thePlayer!!.entityId && mc.thePlayer!!.getDistanceToEntityBox(
                            entity
                    ) <= distance.get()
        }

        when (modeValue.get().toLowerCase()) {
            "grim-reduce" -> {
                if (thePlayer.hurtTime > 0) {
                    thePlayer.motionX += -1.1E-7
                    thePlayer.motionY += -1.1E-7
                    thePlayer.motionZ += -1.2E-7
                    thePlayer.isAirBorne = true
                }
            }
            "grim-pit" ->{

                    if (thePlayer.hurtTime > 0 && !thePlayer.isDead && thePlayer.hurtTime <=5 ) {
                        thePlayer.motionX *= 0.40
                        thePlayer.motionZ *= 0.40
                    }


            }
            "grimac" -> {
                if (thePlayer.hurtTime > 0) {
                    thePlayer.motionX += -1.0E-7
                    thePlayer.motionY += -1.0E-7
                    thePlayer.motionZ += -1.0E-7
                    thePlayer.isAirBorne = true
                }
            }
            "reduce" -> {
                if(mc.thePlayer!!.hurtTime > 0 && velocityInput) {
                    if(mc.thePlayer!!.onGround) {
                        mc.thePlayer!!.motionX *= (mc.thePlayer!!.motionX * (0.56 * Math.random()))
                        mc.thePlayer!!.motionY *= (mc.thePlayer!!.motionX * (0.77 * Math.random()))
                        mc.thePlayer!!.motionZ *= (mc.thePlayer!!.motionX * (0.56 * Math.random()))
                        mc.thePlayer!!.onGround = false
                    } else {
                        mc.thePlayer!!.motionX *= (mc.thePlayer!!.motionX * (0.77 * Math.random()))
                        mc.thePlayer!!.onGround = true
                        mc.thePlayer!!.motionZ *= (mc.thePlayer!!.motionZ * (0.77 * Math.random()))
                    }
                    mc.netHandler.addToSendQueue(classProvider.createCPacketEntityAction(mc.thePlayer!!, ICPacketEntityAction.WAction.START_SNEAKING))
                    velocityInput = false
                }
            }
            "jump" -> if (thePlayer.hurtTime > 0 && thePlayer.onGround) {
                thePlayer.motionY = 0.4199999

                val yaw = thePlayer.rotationYaw * 0.017453292F

                thePlayer.motionX -= sin(yaw) * 0.2
                thePlayer.motionZ += cos(yaw) * 0.2
            }

            "click" -> if (velocityInput && thePlayer.hurtTime >= clickTime.get()) {
                if (!attackRayTrace(clickCount.get(), clickRange.get().toDouble(), thePlayer.sprinting)) {
                    if (clickFakeSwing.get()) mc.netHandler.addToSendQueue(classProvider.createCPacketAnimation())
                    velocityInput = false
                }
            } else velocityInput = false

            "noxz" -> {
                if (velocityInput) {
                    if (mc.thePlayer!!.onGround && mc.thePlayer!!.hurtTime == 9) {
                        if (jumped > 2) {
                            jumped = 0
                        } else {
                            ++jumped
                            if (mc.thePlayer!!.ticksExisted % 5 != 0) mc.gameSettings.keyBindJump.pressed = true
                        }
                    } else if (mc.thePlayer!!.hurtTime == 8) {
                        mc.gameSettings.keyBindJump.pressed = mc.gameSettings.isKeyDown(mc.gameSettings.keyBindJump)
                        velocityInput = false
                    }
                    if (attack) {
                        if (mc.thePlayer!!.movementInput.moveForward > 0.9f && mc.gameSettings.keyBindForward.isKeyDown) {
                            mc.thePlayer!!.motionX *= 0.08
                            mc.thePlayer!!.motionZ *= 0.08
                        }
                        attack = false
                    }
                }
            }

            "smart" -> {
                if (velocityInput) {
                    if (mc.thePlayer!!.onGround && mc.thePlayer!!.hurtTime == 9) {
                        if (jumped > 2) {
                            jumped = 0
                        } else {
                            ++jumped
                            if (mc.thePlayer!!.ticksExisted % 5 != 0) mc.gameSettings.keyBindJump.pressed = true
                        }
                    } else if (mc.thePlayer!!.hurtTime == 8) {
                        mc.gameSettings.keyBindJump.pressed = mc.gameSettings.isKeyDown(mc.gameSettings.keyBindJump)
                        velocityInput = false
                    }
                }
                if (velocityInput2 && velocityTimer.hasTimePassed(msValue.get().toLong())) {
                    if (!doinrange && onlyinRange.get()) return
                    thePlayer.motionX *= horizontalValue.get()
                    thePlayer.motionZ *= horizontalValue.get()
                    thePlayer.motionY *= verticalValue.get()
                    velocityInput2 = false
                }
                if (mc.thePlayer!!.hurtTime > 0) {
                    mc.thePlayer!!.motionX += -1.0E-7
                    mc.thePlayer!!.motionY += -1.0E-7
                    mc.thePlayer!!.motionZ += -1.0E-7
                    mc.thePlayer!!.isAirBorne = true
                }
                if (!mc.thePlayer!!.onGround && mc.thePlayer!!.hurtTime > 0 && mc.thePlayer!!.hurtTime <= 5 && velocityInput3) {
                    if (!doinrange && onlyinRange.get()) return
                    mc.thePlayer!!.motionX *= airReducerValue.get()
                    mc.thePlayer!!.motionZ *= airReducerValue.get()
                    velocityInput3 = false
                }
                if (!legitPush.get()) return
                if (mc.thePlayer!!.onGround && mc.thePlayer!!.hurtTime == 0) {
                    x = mc.thePlayer!!.posX
                    z = mc.thePlayer!!.posZ
                } else if (!mc.thePlayer!!.onGround && mc.thePlayer!!.hurtTime == 5) {
                    d1 = mc.thePlayer!!.posX - x
                    d2 = mc.thePlayer!!.posZ - z
                    pushtick = 5
                }
                if (!doinrange && onlyinRange.get()) return
                if (pushtick > 0) {
                    mc.thePlayer!!.motionX -= (d1 * pushValue.get())
                    mc.thePlayer!!.motionZ -= (d2 * pushValue.get())
                    pushtick--
                }
            }

            "hytpit" -> {
                if (velocityInput) {
                    if (mc.thePlayer!!.onGround && mc.thePlayer!!.hurtTime == 9 && mc.thePlayer!!.sprinting && mc.currentScreen == null) {
                        if (jumped > 2) {
                            jumped = 0
                        } else {
                            ++jumped
                            if (mc.thePlayer!!.ticksExisted % 5 != 0) mc.gameSettings.keyBindJump.pressed = true
                        }
                    } else if (mc.thePlayer!!.hurtTime == 8) {
                        mc.gameSettings.keyBindJump.pressed = mc.gameSettings.isKeyDown(mc.gameSettings.keyBindJump)
                        velocityInput = false
                    }
                }
            }

            "glitch" -> {
                thePlayer.noClip = velocityInput

                if (thePlayer.hurtTime == 7)
                    thePlayer.motionY = 0.4

                velocityInput = false
            }

            "reverse" -> {
                if (!velocityInput)
                    return

                if (!thePlayer.onGround) {
                    MovementUtils.strafe(MovementUtils.speed * reverseStrengthValue.get())
                } else if (velocityTimer.hasTimePassed(80L))
                    velocityInput = false
            }

            "smoothreverse" -> {
                if (!velocityInput) {
                    thePlayer.speedInAir = 0.02F
                    return
                }

                if (thePlayer.hurtTime > 0)
                    reverseHurt = true

                if (!thePlayer.onGround) {
                    if (reverseHurt)
                        thePlayer.speedInAir = reverse2StrengthValue.get()
                } else if (velocityTimer.hasTimePassed(80L)) {
                    velocityInput = false
                    reverseHurt = false
                }
            }

            "aac" -> if (velocityInput) {
                if (velocityTimer.hasTimePassed(80L)) {
                    thePlayer.motionX *= horizontalValue.get()
                    thePlayer.motionZ *= horizontalValue.get()
                    thePlayer.motionY *= verticalValue.get()
                }
                if (mc.thePlayer!!.onGround) {
                    if (mc.thePlayer!!.sprinting) mc.thePlayer!!.jump()
                } else {
                    mc.thePlayer!!.motionX += -1.0E-7
                    mc.thePlayer!!.motionY += -1.0E-7
                    mc.thePlayer!!.motionZ += -1.0E-7
                    mc.thePlayer!!.isAirBorne = true
                }
                velocityInput = false
            }

            "aacpush" -> {
                if (jump) {
                    if (thePlayer.onGround)
                        jump = false
                } else {
                    if (thePlayer.hurtTime > 0 && thePlayer.motionX != 0.0 && thePlayer.motionZ != 0.0)
                        thePlayer.onGround = true
                }

                if (thePlayer.hurtResistantTime >= 19) {
                    val reduce = aacPushXZReducerValue.get()

                    thePlayer.motionX /= reduce
                    thePlayer.motionZ /= reduce
                }
            }

            "aaczero" -> if (thePlayer.hurtTime > 0) {
                if (!velocityInput || thePlayer.onGround || thePlayer.fallDistance > 2F)
                    return

                thePlayer.motionY -= 1.0
                thePlayer.isAirBorne = true
                thePlayer.onGround = true
            } else
                velocityInput = false
        }
    }

    @EventTarget
    fun onPacket(event: PacketEvent) {

        val thePlayer = mc.thePlayer ?: return

        val packet = event.packet
        val aura = LiquidBounce.moduleManager.getModule(KillAura::class.java) as KillAura

        if (classProvider.isSPacketEntityVelocity(packet)) {
            val packetEntityVelocity = packet.asSPacketEntityVelocity()

            if ((mc.theWorld?.getEntityByID(packetEntityVelocity.entityID) ?: return) != thePlayer)
                return

            velocityTimer.reset()

            if (wtapreduce.get()) mc.gameSettings.keyBindForward.pressed = false

            if (stapreduce.get()) {
                mc.thePlayer!!.sprinting = false
            }

            when (modeValue.get().toLowerCase()) {
                "cancel" -> {
                    event.cancelEvent()
                }
                "click" -> {
                    if (packetEntityVelocity.motionX == 0 && packetEntityVelocity.motionZ == 0) return
                    if (attackRayTrace(
                                    clickCount.get(),
                                    clickRange.get().toDouble(),
                                    clickOnPacket.get() && mc.thePlayer!!.sprinting
                            )
                    )
                        velocityInput = true
                }

                "noxz" -> {
                    velocityInput = true
                    if (aura.state && (aura.currentTarget != null) && (mc.thePlayer!!.getDistanceToEntityBox(aura.currentTarget!!) <= 3.00)) {
                        repeat(6) {
                            mc2.connection!!.sendPacket(CPacketConfirmTransaction(100, 100, true))
                            mc.thePlayer!!.sendQueue.addToSendQueue(
                                    classProvider.createCPacketUseEntity(
                                            aura.currentTarget!!,
                                            ICPacketUseEntity.WAction.ATTACK
                                    )
                            )
                            mc.thePlayer!!.sendQueue.addToSendQueue(classProvider.createCPacketAnimation())
                        }
                        attack = true
                    }
                }

                "noxz2" -> {
                    velocityInput = true
                    velocityInput2 = true
                    if (mc.thePlayer!!.onGround) {
                        mc.gameSettings.keyBindJump.pressed = true
                    }
                    if (aura.state && aura.currentTarget != null && mc.thePlayer!!.getDistanceToEntityBox(aura.currentTarget!!) <= 3.01) {
                        //是否疾跑
                        if (mc.thePlayer!!.movementInput.moveForward > 0.9f && mc.thePlayer!!.sprinting && mc.thePlayer!!.serverSprintState) {
                            repeat(5) {
                                mc2.connection!!.sendPacket(CPacketConfirmTransaction(100, 100, true))
                                mc.thePlayer!!.sendQueue.addToSendQueue(
                                        classProvider.createCPacketUseEntity(
                                                aura.currentTarget!!,
                                                ICPacketUseEntity.WAction.ATTACK
                                        )
                                )
                                mc.thePlayer!!.sendQueue.addToSendQueue(classProvider.createCPacketAnimation())
                            }
                            if (thePlayer.isCollidedHorizontally && noblock.get() && !thePlayer.isOnLadder && !thePlayer.isInWater && !thePlayer.isInLava) return
                            if (changesource.get()) {
                                event.packet.asSPacketEntityVelocity().motionX = ((0.077760000 * 8000).toInt())
                                event.packet.asSPacketEntityVelocity().motionZ = ((0.077760000 * 8000).toInt())
                            }
                            attack = true
                        } else {
                            if (mc.thePlayer!!.movementInput.moveForward > 0.9f) {
                                repeat(5) {
                                    mc2.connection!!.sendPacket(CPacketConfirmTransaction(100, 100, true))
                                    mc2.connection!!.networkManager.sendPacket(
                                            CPacketEntityAction(
                                                    mc2.player,
                                                    CPacketEntityAction.Action.START_SPRINTING
                                            )
                                    )
                                    mc.thePlayer!!.sendQueue.addToSendQueue(
                                            classProvider.createCPacketUseEntity(
                                                    aura.currentTarget!!,
                                                    ICPacketUseEntity.WAction.ATTACK
                                            )
                                    )
                                    mc.thePlayer!!.sendQueue.addToSendQueue(classProvider.createCPacketAnimation())
                                }
                                if (thePlayer.isCollidedHorizontally && noblock.get() && !thePlayer.isOnLadder && !thePlayer.isInWater && !thePlayer.isInLava) return
                                if (changesource.get()) {
                                    packetEntityVelocity.motionX = ((0.077760000 * 8000).toInt())
                                    packetEntityVelocity.motionZ = ((0.077760000 * 8000).toInt())
                                }
                                attack = true
                            }
                        }
                    } else if (aura.state && aura.currentTarget != null && mc.thePlayer!!.getDistanceToEntityBox(aura.currentTarget!!) <= 3.01) {
                        //是否疾跑
                        if (mc.thePlayer!!.movementInput.moveForward > 0.9f && mc.thePlayer!!.sprinting && mc.thePlayer!!.serverSprintState) {
                            repeat(5) {
                                mc2.connection!!.sendPacket(CPacketConfirmTransaction(100, 100, true))
                                mc.thePlayer!!.sendQueue.addToSendQueue(
                                        classProvider.createCPacketUseEntity(
                                                aura.currentTarget!!,
                                                ICPacketUseEntity.WAction.ATTACK
                                        )
                                )
                                mc.thePlayer!!.sendQueue.addToSendQueue(classProvider.createCPacketAnimation())
                            }
                            if (thePlayer.isCollidedHorizontally && noblock.get() && !thePlayer.isOnLadder && !thePlayer.isInWater && !thePlayer.isInLava) return
                            if (changesource.get()) {
                                packetEntityVelocity.motionX = ((0.077760000 * 8000).toInt())
                                packetEntityVelocity.motionZ = ((0.077760000 * 8000).toInt())
                            }
                            attack = true
                        } else {
                            if (mc.thePlayer!!.movementInput.moveForward > 0.9f) {
                                repeat(5) {
                                    mc2.connection!!.sendPacket(CPacketConfirmTransaction(100, 100, true))
                                    mc2.connection!!.networkManager.sendPacket(
                                            CPacketEntityAction(
                                                    mc2.player,
                                                    CPacketEntityAction.Action.START_SPRINTING
                                            )
                                    )
                                    mc.thePlayer!!.sendQueue.addToSendQueue(
                                            classProvider.createCPacketUseEntity(
                                                    aura.currentTarget!!,
                                                    ICPacketUseEntity.WAction.ATTACK
                                            )
                                    )
                                    mc.thePlayer!!.sendQueue.addToSendQueue(classProvider.createCPacketAnimation())
                                }
                                if (thePlayer.isCollidedHorizontally && noblock.get() && !thePlayer.isOnLadder && !thePlayer.isInWater && !thePlayer.isInLava) return
                                if (changesource.get()) {
                                    packetEntityVelocity.motionX = ((0.077760000 * 8000).toInt())
                                    packetEntityVelocity.motionZ = ((0.077760000 * 8000).toInt())
                                }
                                attack = true
                            }
                        }
                    }
                }

                "smart" -> {
                    velocityInput = true
                    pos = WBlockPos(mc.thePlayer!!.posX, mc.thePlayer!!.posY, mc.thePlayer!!.posZ)
                    if (mc.thePlayer!!.onGround && (packetEntityVelocity.motionX <= 3600 && packetEntityVelocity.motionY <= 3600 && packetEntityVelocity.motionZ <= 3600)) {
                        if (Auto.get()) {
                            if (packetEntityVelocity.motionX <= 2800 && packetEntityVelocity.motionY <= 2800 && packetEntityVelocity.motionZ <= 2800) {
                                horizontalValue.set(0.4f)
                            } else if (packetEntityVelocity.motionX <= 3000 && packetEntityVelocity.motionY <= 3000 && packetEntityVelocity.motionZ <= 3000) {
                                horizontalValue.set(0.55f)
                            } else if (packetEntityVelocity.motionX <= 3200 && packetEntityVelocity.motionY <= 3200 && packetEntityVelocity.motionZ <= 3200) {
                                horizontalValue.set(0.65f)
                            } else if (packetEntityVelocity.motionX <= 3400 && packetEntityVelocity.motionY <= 3400 && packetEntityVelocity.motionZ <= 3400) {
                                horizontalValue.set(0.74f)
                            } else {
                                horizontalValue.set(0.79f)
                            }
                        }
                        velocityInput2 = true
                    }
                    if (!mc.thePlayer!!.onGround && (packetEntityVelocity.motionX <= 3100 && packetEntityVelocity.motionY <= 3100 && packetEntityVelocity.motionZ <= 3100) && aura.state) velocityInput3 =
                            true
                }

                "simple" -> {
                    val horizontal = horizontalValue.get()
                    val vertical = verticalValue.get()

                    packetEntityVelocity.motionX = (packetEntityVelocity.motionX * horizontal).toInt()
                    packetEntityVelocity.motionY = (packetEntityVelocity.motionY * vertical).toInt()
                    packetEntityVelocity.motionZ = (packetEntityVelocity.motionZ * horizontal).toInt()
                }

                "aac", "reverse", "smoothreverse", "aaczero", "hytpit" -> velocityInput = true

                "glitch" -> {
                    if (!thePlayer.onGround)
                        return

                    velocityInput = true
                    event.cancelEvent()
                }
            }
        }
    }

    @EventTarget
    fun onJump(event: JumpEvent) {
        val thePlayer = mc.thePlayer

        if (thePlayer == null || thePlayer.isInWater || thePlayer.isInLava || thePlayer.isInWeb)
            return

        when (modeValue.get().toLowerCase()) {
            "aacpush" -> {
                jump = true
            }

            "aaczero" -> if (thePlayer.hurtTime > 0)
                event.cancelEvent()
        }
    }

    private fun getMoveYaw(): Float {
        var moveYaw = mc.thePlayer!!.rotationYaw
        if (mc.thePlayer!!.moveForward != 0F && mc.thePlayer!!.moveStrafing == 0F) {
            moveYaw += if (mc.thePlayer!!.moveForward > 0) 0 else 180
        } else if (mc.thePlayer!!.moveForward != 0F && mc.thePlayer!!.moveStrafing != 0F) {
            if (mc.thePlayer!!.moveForward > 0) {
                moveYaw += if (mc.thePlayer!!.moveStrafing > 0) -45 else 45
            } else {
                moveYaw -= if (mc.thePlayer!!.moveStrafing > 0) -45 else 45
            }
            moveYaw += if (mc.thePlayer!!.moveForward > 0) 0 else 180
        } else if (mc.thePlayer!!.moveStrafing != 0F && mc.thePlayer!!.moveForward == 0F) {
            moveYaw += if (mc.thePlayer!!.moveStrafing > 0) -90 else 90
        }
        return moveYaw
    }

    fun attackRayTrace(attack: Int, range: Double, doAttack: Boolean = true): Boolean {
        if (mc.thePlayer == null) return false
        val raycastedEntity = RaycastUtils.raycastEntity(range + 1, object : RaycastUtils.EntityFilter {
            override fun canRaycast(entity: IEntity?): Boolean {
                return entity != null && entity is EntityLivingBase
            }
        })

        raycastedEntity?.let {
            if (it !is EntityPlayer) return true
            if (doAttack) {
                LiquidBounce.eventManager.callEvent(AttackEvent(it))
                repeat(attack) { _ ->
                    if (clickSwing.get()) mc.thePlayer!!.swingItem()
                    else mc.netHandler.addToSendQueue(classProvider.createCPacketAnimation())
                    mc.netHandler.addToSendQueue(
                            classProvider.createCPacketUseEntity(
                                    it,
                                    ICPacketUseEntity.WAction.ATTACK
                            )
                    )
                }
                mc.thePlayer!!.attackTargetEntityWithCurrentItem(it)
            }
            return true
        }
        return false
    }
}

