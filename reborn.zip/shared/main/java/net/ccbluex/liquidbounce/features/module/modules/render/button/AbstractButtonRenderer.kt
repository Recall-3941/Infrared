/*
 * FDPClient Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge by LiquidBounce.
 * https://github.com/SkidderMC/FDPClient/
 */
package net.ccbluex.liquidbounce.features.module.modules.render.button

import net.minecraft.client.Minecraft
import net.minecraft.client.gui.GuiButton
import alien.font.FontLoaders
import java.awt.Color

abstract class AbstractButtonRenderer(protected val button: GuiButton) {
    abstract fun render(mouseX: Int, mouseY: Int, mc: Minecraft)

    open fun drawButtonText(mc: Minecraft) {
        FontLoaders.F18.DisplayFonts(button.displayString,
                (button.x + button.width / 2 -
                        FontLoaders.F18.getStringWidth(button.displayString) / 2).toFloat(),
                button.y + (button.height - 5) / 2f - 1,
                if (button.enabled) Color.WHITE.rgb else Color.GRAY.rgb,
                FontLoaders.F18
        )
    }
}