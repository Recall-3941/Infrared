/*
 * ColorByte Hacked Client
 * A free half-open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/SkidderRyF/ColorByte/
 */

package net.ccbluex.liquidbounce.features.module.modules.render

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.Render2DEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.world.ChestStealer
import net.ccbluex.liquidbounce.injection.forge.mixins.gui.MixinGuiContainer
import net.ccbluex.liquidbounce.utils.render.ColorUtils.getHealthColor
import net.minecraft.client.Minecraft
import net.minecraft.client.gui.ScaledResolution
import net.minecraft.client.gui.inventory.GuiChest
import net.minecraft.util.ResourceLocation
import org.lwjgl.opengl.GL11

@ModuleInfo(name = "Health",description = "Health", category = ModuleCategory.RENDER)
class Health : Module() {
    @EventTarget
    fun onRender2D(e: Render2DEvent){
        val cnm = LiquidBounce.moduleManager.getModule(ChestStealer::class.java) as ChestStealer
        if (mc.currentScreen is MixinGuiContainer && cnm.state && cnm.silentTitleValue.get() && cnm.chestTitleValue.get()) return
        val sr2 = ScaledResolution(mc2)
        val currentTarget = mc.thePlayer
        if (currentTarget != null) {
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f)
            val healthNum = Math.round((mc.thePlayer!!.health * 10.0) / 10.0f).toFloat()
            val abNum = Math.round((Minecraft.getMinecraft().player.absorptionAmount * 10.0) / 10.0f).toFloat()

            //自定义字体时
            var abString = "§e$abNum§e❤"

            if (Minecraft.getMinecraft().player.absorptionAmount <= 0.0f) abString = ""


            //自定义字体
            val text = "$healthNum§c❤ $abString"

            val c = getHealthColor(
                    mc.thePlayer!!.health, mc.thePlayer!!.maxHealth
            )

            mc2.textureManager.bindTexture(ResourceLocation("textures/gui/icons.png"))
            var i2 = 0
            while (i2 < currentTarget.maxHealth / 2) {
                mc2.ingameGUI.drawTexturedModalRect(
                        ((sr2.scaledWidth / 2) - currentTarget.maxHealth / 2.0f * 10.0f / 2.0f + 9 + (i2 * 8)).toInt(),
                        (sr2.scaledHeight / 2 + 6),
                        16,
                        0,
                        9,
                        9
                )
                ++i2
            }
            i2 = 0
            while (i2 < currentTarget.health / 2.0) {
                mc2.ingameGUI.drawTexturedModalRect(
                        ((sr2.scaledWidth / 2) - currentTarget.maxHealth / 2.0f * 10.0f / 2.0f + 9 + (i2 * 8)).toInt(),
                        (sr2.scaledHeight / 2 + 6),
                        52,
                        0,
                        9,
                        9
                )
                ++i2
            }
            mc.fontRendererObj.drawCenteredString(
                    text,
                    (sr2.scaledWidth / 2 - mc.fontRendererObj.getStringWidth(currentTarget.health.toInt().toString()) / 2).toFloat() + 5f,
                    (sr2.scaledHeight / 2 + 16).toFloat(),
                    c,
                    true
            )
        }
    }
}