package net.ccbluex.liquidbounce.features.module.modules.render

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.ListValue
import net.ccbluex.liquidbounce.value.TextValue

@ModuleInfo(name = "Titled", description = "更改标题", category = ModuleCategory.RENDER)
class Titled : Module(){
    private val TitleValue = TextValue("Title", "Destiny Reborn | Dev:Last && Azusa-Dasuki")

    @EventTarget
    override fun onEnable() {
        org.lwjgl.opengl.Display.setTitle(TitleValue.get())
    }
}