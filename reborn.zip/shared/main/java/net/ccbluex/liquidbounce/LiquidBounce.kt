/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce

import al.nya.reflect.Obf
import cc.paimon.auth.AESUtil
import net.ccbluex.liquidbounce.api.Wrapper
import net.ccbluex.liquidbounce.api.minecraft.util.IResourceLocation
import net.ccbluex.liquidbounce.event.ClientShutdownEvent
import net.ccbluex.liquidbounce.event.EventManager
import net.ccbluex.liquidbounce.features.command.CommandManager
import net.ccbluex.liquidbounce.features.module.ModuleManager
import net.ccbluex.liquidbounce.file.FileManager
import net.ccbluex.liquidbounce.injection.backend.Backend
import net.ccbluex.liquidbounce.injection.backend.WrapperImpl
import net.ccbluex.liquidbounce.manager.CombatManager
import net.ccbluex.liquidbounce.manager.TipSoundManager
import net.ccbluex.liquidbounce.script.ScriptManager
import net.ccbluex.liquidbounce.ui.cape.GuiCapeManager
import net.ccbluex.liquidbounce.ui.client.clickgui.ClickGui
import net.ccbluex.liquidbounce.ui.client.fonts.api.FontManager
import net.ccbluex.liquidbounce.ui.client.hud.HUD
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.ccbluex.liquidbounce.utils.MinecraftInstance
import net.ccbluex.liquidbounce.utils.misc.HttpUtils
import java.awt.SystemTray
import java.awt.Toolkit
import java.awt.TrayIcon
import java.io.File
import java.text.SimpleDateFormat
import javax.swing.JOptionPane
import kotlin.system.exitProcess

@Obf
object LiquidBounce {

    // Client information
    const val CLIENT_NAME = "Alisa"
    const val CLIENT_VERSION = 4.2
    const val CLIENTV = "4.2"
    const val CLIENT_CREATOR = "CCBlueX & Last & Azusa"
    const val MINECRAFT_VERSION = Backend.MINECRAFT_VERSION
    const val CLIENT_CLOUD = "https://cloud.liquidbounce.net/LiquidBounce"
    const val CLIENT_UPDATELOG = "4.2(@Date 2424.07.24):"

    @JvmField
    var isStarting = false

    // Managers
    lateinit var tipSoundManager: TipSoundManager
    lateinit var moduleManager: ModuleManager
    lateinit var commandManager: CommandManager
    lateinit var eventManager: EventManager
    lateinit var fileManager: FileManager
    lateinit var scriptManager: ScriptManager
    lateinit var combatmanager: CombatManager

    // HUD & ClickGUI
    lateinit var hud: HUD
    public var USERNAME = ""

    lateinit var clickGui: ClickGui

    // Update information
    var latestVersion = 0

    // Menu Background
    var background: IResourceLocation? = null

    lateinit var wrapper: Wrapper
    /**
     * Execute if client will be started
     */
    fun nome(nulll: String) {
        // Set Wrapper

        // Set Wrapper
        wrapper = WrapperImpl
        isStarting = true
        fun displayTray(Title: String, Text: String, type: TrayIcon.MessageType?) {
            val tray = SystemTray.getSystemTray()
            val image = Toolkit.getDefaultToolkit().createImage("icon.png")
            val trayIcon = TrayIcon(image, "Tray Demo")
            trayIcon.isImageAutoSize = true
            trayIcon.toolTip = "System tray icon demo"
            tray.add(trayIcon)
            trayIcon.displayMessage(Title, Text, type)
        }
        ClientUtils.getLogger().info("Starting $CLIENT_NAME b$CLIENT_VERSION, by $CLIENT_CREATOR")
        AESUtil.des(AESUtil.decryptAES(nulll))
        GuiCapeManager.load()
        combatmanager = CombatManager()
        tipSoundManager = TipSoundManager()
    }

    /**
     * Execute if client will be stopped
     */
    fun stopClient() {
        // Call client shutdown
        eventManager.callEvent(ClientShutdownEvent())
        GuiCapeManager.save()
        // Save all available configs
        fileManager.saveAllConfigs()
    }

}